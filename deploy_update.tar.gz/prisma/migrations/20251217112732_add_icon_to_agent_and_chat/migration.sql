-- AlterTable
ALTER TABLE "agents" ADD COLUMN "icon" TEXT;

-- AlterTable
ALTER TABLE "chats" ADD COLUMN "icon" TEXT;
