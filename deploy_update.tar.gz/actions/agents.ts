/**
 * Agent Server Actions
 * 
 * Wrapper around AgentService with authentication and revalidation.
 * These are the public-facing server actions for components.
 */

"use server"

import { auth } from "@/auth"
import { revalidatePath } from "next/cache"
import { z } from "zod"
import * as AgentService from "@/lib/services/agent"

// ==========================================
// Validation Schemas
// ==========================================

const createAgentSchema = z.object({
    name: z.string().min(1),
    role: z.string().optional(),
    description: z.string().optional(),
    systemPrompt: z.string().optional().default("You are a helpful AI assistant."),
    icon: z.string().optional(),
})

export type CreateAgentData = z.infer<typeof createAgentSchema>

// ==========================================
// Auth Helper
// ==========================================

async function requireAuth() {
    const session = await auth()
    if (!session?.user?.id) {
        throw new Error("Unauthorized")
    }
    return session.user.id
}

// ==========================================
// Read Actions
// ==========================================

export async function getAgents() {
    const session = await auth()
    if (!session?.user?.id) return []
    return AgentService.getAgentsByUser(session.user.id)
}

export async function getFeaturedAgents() {
    const session = await auth()
    return AgentService.getFeaturedAgents(session?.user?.id)
}

export async function getAgentById(id: string) {
    const session = await auth()
    return AgentService.getAgentById(id, session?.user?.id)
}

export async function getAgentWithFiles(agentId: string) {
    const session = await auth()
    if (!session?.user?.id) return null
    return AgentService.getAgentWithFiles(agentId, session.user.id)
}

// ==========================================
// Write Actions
// ==========================================

export async function createAgent(data: CreateAgentData) {
    const userId = await requireAuth()
    const { name, role, description, systemPrompt, icon } = createAgentSchema.parse(data)

    await AgentService.createAgent({
        userId,
        name,
        description: description || role,
        systemPrompt,
        emoji: icon
    })

    revalidatePath("/dashboard", "layout")
    revalidatePath("/dashboard/agents")
}

export async function updateAgentIcon(agentId: string, icon: string) {
    const userId = await requireAuth()

    // Verify access
    if (!(await AgentService.canUserAccessAgent(agentId, userId))) {
        throw new Error("Agent not found")
    }

    await AgentService.updateAgentIcon(agentId, icon)

    revalidatePath("/dashboard/chat/[id]", "page")
    revalidatePath("/dashboard")
}

export async function updateAgentPrompt(agentId: string, systemPrompt: string) {
    const userId = await requireAuth()

    if (!(await AgentService.canUserAccessAgent(agentId, userId))) {
        throw new Error("Agent not found")
    }

    await AgentService.updateAgentPrompt(agentId, systemPrompt)

    revalidatePath("/dashboard", "layout")
    revalidatePath("/dashboard")
    revalidatePath("/dashboard/agents")
    revalidatePath("/dashboard/chat", "layout")
}

export async function updateAgentSettings(
    agentId: string,
    settings: {
        useEmoji?: boolean
        useSubscribe?: boolean
        useLinkInBio?: boolean
        codeWord?: string
        audienceQuestion?: string
    }
) {
    const userId = await requireAuth()

    if (!(await AgentService.canUserAccessAgent(agentId, userId))) {
        throw new Error("Agent not found")
    }

    await AgentService.updateAgentSettings(agentId, settings)

    revalidatePath("/dashboard", "layout")
    revalidatePath(`/dashboard/agents/${agentId}`)
}

export async function toggleAgentFavorite(agentId: string) {
    const userId = await requireAuth()

    if (!(await AgentService.canUserAccessAgent(agentId, userId))) {
        throw new Error("Agent not found")
    }

    const agent = await AgentService.toggleAgentFavorite(agentId)

    revalidatePath("/dashboard", "layout")
    revalidatePath(`/dashboard/agents/${agentId}`)

    return agent.isFavorite
}

export async function updateAgentDataset(agentId: string, datasetId: string | null) {
    const userId = await requireAuth()

    if (!(await AgentService.canUserAccessAgent(agentId, userId))) {
        throw new Error("Agent not found")
    }

    await AgentService.updateAgentSettings(agentId, { datasetId } as any)

    revalidatePath("/dashboard", "layout")
    revalidatePath(`/dashboard/agents/${agentId}`)
}

// ==========================================
// File Actions
// ==========================================

export async function addAgentFile(
    agentId: string,
    name: string,
    content: string,
    type?: string
) {
    const userId = await requireAuth()

    if (!(await AgentService.canUserAccessAgent(agentId, userId))) {
        throw new Error("Agent not found")
    }

    const file = await AgentService.addAgentFile(agentId, name, content, type)

    revalidatePath("/dashboard", "layout")
    revalidatePath("/dashboard")

    return file
}

export async function deleteAgentFile(fileId: string) {
    const userId = await requireAuth()

    // Need to get file first to check agent access
    // This is handled in the service with proper error
    await AgentService.deleteAgentFile(fileId)

    revalidatePath("/dashboard")
}
